<style>
	nav{height: 45px;line-height: 40px;background: #9c27b0;}
	nav .brand-logo{font-size: 20px;}
</style>
<!-- navbar section -->
	<nav>
		<div class="nav-wrapper">
			<a href="<?= base_url('index.php/Home/dashboard'); ?>" class="brand-logo left">Dashboard</a>
			<!-- mobile menu section -->
			<a href="#!" class="sidenav-trigger right" data-target="mobile-menu"><i class="material-icons" style="line-height: 40px;">menu</i></a>
			<!-- mobile menu section -->
		</div>
	</nav>
	<!-- navbar section -->
	<!-- mobile menu section -->
	<ul class="sidenav hide-on-large-only" id="mobile-menu">
		<li><a href="<?= base_url('index.php/Home/dashboard'); ?>">Dashboard</a></li>
		<li><a href="<?= base_url('index.php/Home/new_customer'); ?>">New Customer Register</a></li>
		<li><a href="<?= base_url('index.php/Home/all_data_manage/udhar'); ?>">All Data Manage</a></li>
		<li><a href="#!" style="background: rgba(0,0,0,0.08);">Account Settings Options</a></li>
		<li><a href="">Profile Settings</a></li>
		<li><a href="<?= base_url('index.php/Home/logout'); ?>">Logout Account</a></li>
	</ul>
	<!-- mobile menu section -->