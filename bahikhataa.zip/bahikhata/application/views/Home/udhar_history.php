<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<html>
<head>
	<title>Udhar History - Udhar Bahikhata</title>
	<?php $this->load->view('Home/css-file'); ?>
	<style type="text/css">
		body{background: rgba(0,0,0,0.08);}
		.container{width: 100%;}
		
	</style>
</head>
<body>
	<!-- body section -->
	<!-- navbar section -->
	<?php $this->load->view('Home/navbar'); ?>
	<!-- navbar section -->
	<!-- udhar history section -->
	<div class="container" style="padding: 20px;background: white;margin-top: 10px;">
		<h4 style="font-weight: 500;text-align: center;"><span class="fas fa-rupee-sign" style="font-size: 22px;"></span>&nbsp;<?php
		$udhar_amount_count = 0;
		if(count($udhar_history)){
			foreach($udhar_history as $udhar){
				$udhar_amount_count += $udhar->amount;
			}
			echo number_format($udhar_amount_count);
		}
		else{
			echo $udhar_amount_count = 0;
		}
		?></h4>
		<h6 style="font-size: 14px;text-align: center;margin-top: 0px;">All Udhar Amounts</h6>
	</div>
	<?php if(count($udhar_history)): ?>
		<?php foreach($udhar_history as $udhar_his): ?>
	<div class="container" style="padding: 15px;background: white;margin-top: 10px;">
		<h5 style="margin-top: 5px;"><span class="fas fa-rupee-sign" style="font-size: 22px;"></span>&nbsp;<?= number_format($udhar_his->amount); ?><span class="right" style="font-size: 15px;"><?= date('M d',strtotime($udhar_his->udhar_date))."/". $udhar_his->time; ?></span></h5>
		<h6><?= $udhar_his->udhar_desc; ?></h6>
	</div>
	<?php endforeach;
	else: ?>
		<div class="container" style="padding: 15px;background: white;margin-top: 10px;">
			<h6 class="center-align" style="margin-top: 5px;font-weight: 500;">Udhar History Not Found.</h6>
		</div>
	<?php endif; ?>
	<!-- udhar history section -->
	<!-- body section -->
<?php $this->load->view('Home/js-file'); ?>
</body>
</html>