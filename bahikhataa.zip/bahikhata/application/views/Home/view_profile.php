<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<html>
<head>
	<title>Edit Customer Profile - Udhar Bahikhata</title>
	<?php $this->load->view('Home/css-file'); ?>
	<style type="text/css">
		body{background: rgba(0,0,0,0.08);}
		.container{width: 100%;}
		#customer_name,#mobile_no{border:2px solid silver;box-shadow: none;padding-left: 5px;padding-right: 5px;width: 96%;border-radius: 3px;font-weight: 500;}

		#address{border:2px solid silver;resize: none;border-radius: 3px;padding: 10px;height: 100px;outline: none;font-size: 16px;}
	</style>
</head>
<body>
	<!-- body section -->
	<!-- navbar section -->
	<?php $this->load->view('Home/navbar'); ?>
	<!-- navbar section -->
	<!-- message section -->
	<?php if($msg = $this->session->flashdata('msg')): ?>
	<div class="container" style="padding: 15px;background: green;margin-top: 10px;">
		<h6 style="margin-top: 5px;color: white;text-align: center;"><?= $msg; ?></h6>
	</div>
	<?php endif; ?>
	<!-- message section -->
	<!-- new udhar entry form -->
	<div class="container" style="padding: 15px;background: white;margin-top: 10px;">
		<h5 style="margin-top: 5px;font-weight: 500;color: grey;margin-bottom: 15px;">Edit Customer Profile</h5>
		<?= form_open('Home/update_customer/'.$profile->customer_id); ?>
		<h6>Customer Name</h6>
		<input type="text" name="customer_name" id="customer_name" placeholder="Enter Your Customer Name" value="<?= $profile->name; ?>" required>
		<h6>What's App Number</h6>
		<input type="number" name="mobile_no" id="mobile_no" value="<?= $profile->mobile; ?>" placeholder="Enter Whatsapp Number" required>
		<h6>Address</h6>
		<textarea name="address" id="address" placeholder="Enter Address"><?= $profile->address; ?></textarea>
		<button type="submit" class="btn waves-effect waves-light" style="background: #9c27b0;height: 45px;width: 100%;text-transform: capitalize;font-size: 16px;margin-top: 10px;">Update Customer</button>
		<?= form_close(); ?>
		<h6 style="font-weight: 500;">Note : </h6>
		<h6 style="font-weight: 500;">1. Enter Customer WhatsApp No.</h6>
		<h6 style="font-weight: 500;">2. Enter Full Address</h6>
	</div>
	<!-- new udhar entry form -->
	<!-- body section -->
<?php $this->load->view('Home/js-file'); ?>
</body>
</html>