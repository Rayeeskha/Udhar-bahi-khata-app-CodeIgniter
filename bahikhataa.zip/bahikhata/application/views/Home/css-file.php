<?= link_tag('assets/materialize/css/materialize.css'); ?>
<!-- font awesome css file include -->
<?= link_tag('assets/font-awesome/css/all.css'); ?>
<!-- material icon link -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
