<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<html>
<head>
	<title>Udhar Bahikhata - Dashboard</title>
	<?php $this->load->view('Home/css-file'); ?>
	<style type="text/css">
		body{background: rgba(0,0,0,0.06);}
		nav{margin-bottom: 0px!important;box-shadow: none;}

		.container{width: 100%;}
		.tabs .tab a{color: white;text-transform: capitalize;font-size: 16px;}
		.tabs .tab a:hover, .tabs .tab a.active{color: white;box-shadow: none;}
		.tabs .tab a:focus, .tabs .tab a:focus.active{background: #9c27b0;color: white;border-bottom: 2px solid #9c27b0;box-shadow: none;}
		.tabs .indicator{background: #9c27b0;border:none;}


	</style>
</head>
<body>
	<!-- body section -->
	<div class="container" style="padding: 10px;background: #9c27b0;margin-bottom: 0px;">
		<h6 style="margin-top: 5px;"><a href="#!" style="color:white;font-size: 20px;">All Data</a>
		<a href="<?= base_url('index.php/Home/dashboard'); ?>" class="right" style="color: white;">Back to Home</a></h6>
	</div>
	<!-- tab section -->
		<ul class="tabs" style="background: #9c27b0;margin-top: 0px;">
			<?php if($tab == "udhar"): ?>
			<li class="tab"><a href="#udhar" class="active">Udhar</a></li>
			<?php else: ?>
			<li class="tab"><a href="#udhar">Udhar</a></li>
			<?php endif; ?>

			<?php if($tab == "advance"): ?>
			<li class="tab"><a href="#advance" class="active">Payments</a></li>
			<?php else: ?>
			<li class="tab"><a href="#advance">Payments</a></li>
			<?php endif; ?>

			<?php if($tab == "customer"): ?>
			<li class="tab"><a href="#customers" class="active">Customers</a></li>
			<?php else: ?>
			<li class="tab"><a href="#customers">Customers</a></li>
			<?php endif; ?>
		</ul>

		<div id="udhar">
			<!-- message section -->
			<?php if($msg = $this->session->flashdata('msg')): ?>
			<div class="container" style="padding: 15px;background: green;margin-top: 10px;">
				<h6 style="margin-top: 5px;color: white;text-align: center;"><?= $msg; ?></h6>
			</div>
			<?php endif; ?>
			<!-- message section -->
			<div class="container" style="padding:15px;background: white;margin-top: 10px;">
				<h6 style="font-weight: 500;margin-top: 5px;">Udhar Customer List</h6>
			</div>
			<?php if(count($all_udhar)): ?>
				<?php foreach($all_udhar as $udhar): ?>
	<!-- customer list section -->
	<div class="container" style="padding:15px;background: white;margin-top: 10px;">
		<div class="row" style="margin-bottom: 0px;">
			<div class="col l8 m8 s8">
		<h4 style="margin-top: 5px;font-size: 25px;"><span class="fas fa-rupee-sign" style="font-size: 16px;"></span>&nbsp;<?= $udhar->amount; ?></h4>
		<!-- customer profile section -->
		<div class="row" style="margin-bottom: 0px;">
			<div class="col l4 m4 s3">
				<center><img src="<?= base_url('assets/image/user-profile.png'); ?>" class="responsive-img" style="padding:2px;border:2px solid #9c27b0;width: 35px;height: 35px;border-radius: 100%;"></center>
			</div>
			<div class="col l8 m8 s9">
				<h6 style="margin-top: 2px;font-size: 13px;">Udhar by <?= $udhar->customer_name; ?></h6>
				<h6 style="font-size: 13px;margin-top: 0px;"><?= date('d M Y',strtotime($udhar->udhar_date))?> - <?= $udhar->time; ?></h6>
			</div>
		</div>
		<!-- customer profile section -->
	</div>
	<div class="col l4 m4 s4">
		<?php if($udhar->status == "Paid"): ?>
			<br/>
			<span class="center-align" style="padding: 5px 15px;font-size: 14px;color: white;background: #6dc16d;border-top-right-radius: 30px;border-top-left-radius: 30px;border-bottom-right-radius: 30px;border-bottom-left-radius: 30px;"><span class="fas fa-check"></span>&nbsp;Paid</span>
			<?php else: ?>
		<!-- button section -->
		<center>
		<a href="<?= base_url('index.php/Home/single_payment/'.$udhar->udhar_id); ?>" class="btn waves-effect waves-light" style="margin-bottom: 10px;width: 100%;background: #9c27b0;margin-top: 15px;">Pay</a>
		</center>
		<!-- button section -->
		<?php endif; ?>
	</div>
	</div>
	<!-- customer list section -->
	</div>
	<?php endforeach;
	else: ?>
		<div class="row">
			<div class="col l12 m12 s12">
				<h6 class="center-align" style="font-weight: 500;">Udhar Entry Not Found.</h6>
			</div>
		</div>
	<?php endif; ?>
		</div>

		<div id="advance">
			<div class="container" style="padding:15px;background: white;margin-top: 10px;">
				<h6 style="font-weight: 500;margin-top: 5px;">Payment Receive Cusotmers</h6>
			</div>
			<?php if(count($payments)): ?>
				<?php foreach($payments as $pay): ?>
	<!-- customer list section -->
	<div class="container" style="padding:15px;background: white;margin-top: 10px;">
		<div class="row">
			<div class="col l8 m8 s8">
		<h4 style="margin-top: 5px;font-size: 25px;"><span class="fas fa-rupee-sign" style="font-size: 16px;"></span>&nbsp;<?= $pay->payment_amount; ?></h4>
		<!-- customer profile section -->
		<div class="row">
			<div class="col l4 m4 s3">
				<center><img src="<?= base_url('assets/image/user-profile.png'); ?>" class="responsive-img" style="padding:2px;border:2px solid #9c27b0;width: 35px;height: 35px;border-radius: 100%;"></center>
			</div>
			<div class="col l8 m8 s9">
				<h6 style="margin-top: 2px;font-size: 13px;">Payment by <?= $pay->customer_name; ?></h6>
				<h6 style="font-size: 13px;margin-top: 0px;"><?= date('d M.Y',strtotime($pay->date)); ?> - <?= $pay->time; ?></h6>
			</div>
		</div>
		<!-- customer profile section -->
	</div>
	<div class="col l4 m4 s4">
		<!-- button section -->
		<center>
			<br/>
			<span class="center-align" style="padding: 5px 15px;font-size: 14px;color: white;background: #9c27b0;border-top-right-radius: 30px;border-top-left-radius: 30px;border-bottom-right-radius: 30px;border-bottom-left-radius: 30px;">&nbsp;Received</span>
		</center>
		<!-- button section -->
	</div>
	</div>
	<!-- customer list section -->
	</div>
	<?php endforeach;
	else: ?>
	<?php endif; ?>
		</div>

		<div id="customers">
			<div class="container" style="padding:15px;background: white;margin-top: 10px;margin-bottom: 10px;">
				<h6 style="font-weight: 500;margin-top: 5px;">All Customers (<?= count($all_customer); ?>)</h6>
			</div>
			<?php if(count($all_customer)): ?>
				<?php foreach($all_customer as $all_cus): ?>
			<!-- customer list seciton -->
			<div class="container" style="padding:5px;background: white;">
				
				<a href="<?= base_url('index.php/Home/customer_option/'.$all_cus->customer_id); ?>"><div class="row" style="margin-bottom: 5px;border-bottom: 1px dashed silver;">
					<div class="col l2 m2 s2">
						<h5><span class="fas fa-user" style="border:2px solid #9c27b0;color:#9c27b0;padding: 10px;"></span></h5>
					</div>
					<div class="col l6 m6 s6">
						<h6 style="font-size: 15px;font-weight: 500;margin-top: 15px;color: black;"><?= $all_cus->name; ?></h6>
						<h6 style="margin-top: 0px;font-size: 14px;color: grey">Since : <?= date('M d-y',strtotime($all_cus->date)); ?></h6>
					</div>
					<div class="col l4 m4 s4">
						<?php if($all_cus->udhar_amount > 0): ?>
						<h5 style="font-weight: 500;margin-top: 5px;color: red;font-size: 19px;"><span class="fas fa-rupee-sign" style="font-size: 14px;"></span>&nbsp;<?= $all_cus->udhar_amount; ?></h5>
						<h6 style="margin-top: 0px;color: grey;font-size: 14px;">Udhar Amt.</h6>
						<?php else: ?>
							<h5 style="font-weight: 500;margin-top: 5px;color: green;font-size: 19px;"><span class="fas fa-rupee-sign" style="font-size: 14px;"></span>&nbsp;<?= $all_cus->pay_amount; ?></h5>
						<h6 style="margin-top: 0px;color: grey;font-size: 14px;">Advance Amt.</h6>
						<?php endif; ?>
					</div>
				</div></a>
				</div>
			<?php endforeach;
			else: ?>
				<div class="row">
					<div class="col l12 m12 s12">
						<h6 class="center-align" style="font-weight: 500;">Customer Not Found.</h6>
					</div>
				</div>
			<?php endif; ?>
			
			<!-- customer list seciton -->
		</div>
	<!-- tab section -->
	<!-- body section -->
<?php $this->load->view('Home/js-file'); ?>
</body>
</html>