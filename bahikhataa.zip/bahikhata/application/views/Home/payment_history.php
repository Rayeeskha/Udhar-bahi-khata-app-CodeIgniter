<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<html>
<head>
	<title>Payment History - Udhar Bahikhata</title>
	<?php $this->load->view('Home/css-file'); ?>
	<style type="text/css">
		body{background: rgba(0,0,0,0.08);}
		.container{width: 100%;}
		
	</style>
</head>
<body>
	<!-- body section -->
	<!-- navbar section -->
	<?php $this->load->view('Home/navbar'); ?>
	<!-- navbar section -->
	<!-- udhar history section -->
	<div class="container" style="padding: 20px;background: white;margin-top: 10px;">
		<h4 style="font-weight: 500;text-align: center;"><span class="fas fa-rupee-sign" style="font-size: 22px;"></span>&nbsp;<?php
		$payment_amount_count = 0;
		if(count($payment_history)){
			foreach($payment_history as $payment){
				$payment_amount_count += $payment->payment_amount;
			}
			echo number_format($payment_amount_count);
		}
		else{
			echo $payment_amount_count = 0;
		}
		?></h4>
		<h6 style="font-size: 14px;text-align: center;margin-top: 0px;">All Payments</h6>
	</div>
	<?php if(count($payment_history)): ?>
		<?php foreach($payment_history as $payment_his): ?>
	<div class="container" style="padding: 15px;background: white;margin-top: 10px;">
		<h5 style="margin-top: 5px;"><span class="fas fa-rupee-sign" style="font-size: 22px;"></span>&nbsp;<?= number_format($payment_his->payment_amount); ?><span class="right" style="font-size: 15px;"><?= date('M d',strtotime($payment_his->date))."/". $payment_his->time; ?></span></h5>
		<h6>Payment By <?= $payment_his->customer_name; ?></h6>
	</div>
	<?php endforeach;
	else: ?>
		<div class="container" style="padding: 15px;background: white;margin-top: 10px;">
			<h6 class="center-align" style="margin-top: 5px;font-weight: 500;">Udhar History Not Found.</h6>
		</div>
	<?php endif; ?>
	<!-- udhar history section -->
	<!-- body section -->
<?php $this->load->view('Home/js-file'); ?>
</body>
</html>