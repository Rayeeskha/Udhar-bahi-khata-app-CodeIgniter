<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<html>
<head>
	<title>New Udhar Entry - Udhar Bahikhata</title>
	<?php $this->load->view('Home/css-file'); ?>
	<style type="text/css">
		body{background: rgba(0,0,0,0.08);}
		.container{width: 100%;}
		#customer_name,#amount{border:2px solid silver;box-shadow: none;padding-left: 5px;padding-right: 5px;width: 96%;border-radius: 3px;font-weight: 500;}

		#udhar_desc{border:2px solid silver;resize: none;border-radius: 3px;padding: 10px;height: 100px;outline: none;font-size: 16px;}
	</style>
</head>
<body>
	<!-- body section -->
	<!-- navbar section -->
	<?php $this->load->view('Home/navbar'); ?>
	<!-- navbar section -->
	<!-- message section -->
	<?php if($msg = $this->session->flashdata('msg')): ?>
	<div class="container" style="padding: 15px;background: green;margin-top: 10px;">
		<h6 style="margin-top: 5px;color: white;text-align: center;"><?= $msg; ?></h6>
	</div>
	<?php endif; ?>
	<!-- message section -->
	<!-- new udhar entry form -->
	<div class="container" style="padding: 15px;background: white;margin-top: 10px;">
		<h5 style="margin-top: 5px;font-weight: 500;color: grey;margin-bottom: 15px;">New Udhar Entry</h5>
		<?= form_open('Home/submit_udhar_entry/'.$profile->customer_id); ?>
		<h6>Customer Name</h6>
		<input type="text" name="customer_name" id="customer_name" placeholder="Enter Your Customer Name" value="<?= $profile->name; ?>" required>
		<h6>Amount&nbsp;(<span class="fas fa-rupee-sign" style="font-size: 13px;"></span>)</h6>
		<input type="text" name="amount" id="amount" placeholder="Enter Amount" required>
		<h6>Udhar Description</h6>
		<textarea name="udhar_desc" id="udhar_desc" placeholder="Enter Udhar Description"></textarea>
		<button type="submit" class="btn waves-effect waves-light" style="background: #9c27b0;height: 45px;width: 100%;text-transform: capitalize;font-size: 16px;margin-top: 10px;">Submit Entry</button>
		<?= form_close(); ?>
		<h6 style="font-weight: 500;">Note : </h6>
		<h6 style="font-weight: 500;">1. Enter Udhar Amount (INR)</h6>
		<h6 style="font-weight: 500;">2. Enter Udhar Description (Product Name)</h6>
	</div>
	<!-- new udhar entry form -->
	<!-- body section -->
<?php $this->load->view('Home/js-file'); ?>
</body>
</html>