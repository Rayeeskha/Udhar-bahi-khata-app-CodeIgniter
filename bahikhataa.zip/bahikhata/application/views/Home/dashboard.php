<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<html>
<head>
	<title>Udhar Bahikhata - Dashboard</title>
	<?php $this->load->view('Home/css-file'); ?>
	<style type="text/css">
		body{background: rgba(0,0,0,0.06);}
		

		.container{width: 100%;}
	</style>
</head>
<body>
	<!-- body section -->
	<?php $this->load->view('Home/navbar'); ?>
	<!-- udhar section -->
	<div class="container" style="padding:15px;background: white;margin-top: 10px;">
		<h6 style="color: red;font-weight: 500;">Udhar Amount</h6>
		<h4 style="margin-top: 5px;"><span class="fas fa-rupee-sign"></span>&nbsp;<?php
		$count_udhar_amount = 0;
		if(count($udhar_amount)){
			foreach($udhar_amount as $u_amount){
				$count_udhar_amount += $u_amount->amount;
			}
			echo number_format($count_udhar_amount);
		}	
		else{
			echo $count_udhar_amount = 0;
		}
		?></h4>
		<h6 class="right-align" style="font-weight: 500;"><a href="<?= base_url('index.php/Home/all_data_manage/udhar'); ?>" style="color: green;">View More</a></h6>
	</div>
	<!-- udhar section -->

	<!-- advance section -->
	<div class="container" style="padding:15px;background: white;margin-top: 10px;">
		<h6 style="color: green;font-weight: 500;">Udhar Payments</h6>
		<h4 style="margin-top: 5px;"><span class="fas fa-rupee-sign"></span>&nbsp;<?php
		$count_pay_amount = 0;
		if(count($pay_amount)){
			foreach($pay_amount as $p_amount){
				$count_pay_amount += $p_amount->payment_amount;
			}
			echo number_format($count_pay_amount);
		}	
		else{
			echo $count_pay_amount = 0;
		}
		?></h4>
		<h6 class="right-align" style="font-weight: 500;"><a href="<?= base_url('index.php/Home/all_data_manage/advance'); ?>" style="color: green;">View More</a></h6>
	</div>
	<!-- advance section -->

	<!-- advance section -->
	<div class="container" style="padding:15px;background: white;margin-top: 10px;">
		<div class="row" style="margin-bottom: 10px;margin-top: 10px;">
			<div class="col l6 m6 s6">
				<h6 style="color: grey;font-weight: 500;text-align: center;">All Customer's</h6>
				<h4 style="margin-top: 5px;text-align: center;"><a href="<?= base_url('index.php/Home/all_data_manage/customer'); ?>" style="color: black;"><span class="fas fa-users"></span>&nbsp;<?= count($all_customer); ?></a></h4>	
			</div>
			<div class="col l6 m6 s6">
				<h6 style="color: grey;font-weight: 500;text-align: center;">New Customer's</h6>
				<h4 style="margin-top: 5px;text-align: center;"><a href="<?= base_url('index.php/Home/all_data_manage/customer'); ?>" style="color: black;"><span class="fas fa-user"></span>&nbsp;<?php
				$new_count = 0;
				if(count($all_customer)){
					foreach($all_customer as $all_cus){
						if($all_cus->month == date('m')){
							$new_count++;
						}
					}
					echo $new_count;
				}
				else{
					echo "0";
				}
				?></a></h4>	
			</div>
		</div>
	</div>
	<!-- advance section -->
	
	<!-- body section -->
<?php $this->load->view('Home/js-file'); ?>
</body>
</html>