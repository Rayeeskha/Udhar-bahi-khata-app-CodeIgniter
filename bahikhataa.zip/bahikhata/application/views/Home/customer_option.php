<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<html>
<head>
	<title>Udhar Bahikhata - Option</title>
	<?php $this->load->view('Home/css-file'); ?>
	<style type="text/css">
		body{background: rgba(0,0,0,0.08);}
		.container{width: 100%;padding: 25px;}
	</style>
</head>
<body>
	<!-- body section -->
	<!-- navbar include -->
	<?php $this->load->view('Home/navbar'); ?>
	<!-- navbar include -->
	<!-- customer profile section -->
	<div class="container" style="padding:15px;background: white;margin-top: 10px;">
		<div class="row" style="margin-bottom: 0px;">
			<div class="col l3 m3 s3">
				<h6><span class="fas fa-user" style="font-size: 25px;padding: 13px;border:2px solid #9c24b0;color: #9c24b0;"></span></h6>
			</div>
			<div class="col l9 m9 s9">
				<h6 style="font-weight: 500;"><?= $profile->name; ?></h6>
				<h6 style="margin-top: 0px;"><?= $profile->address; ?></h6>
				<h6 style="margin-top: 0px;">Since - <?= date('d M Y',strtotime($profile->date)); ?></h6>
			</div>
		</div>
	</div>
	<!-- customer profile section -->
	<!-- customer option section -->
	<div class="container" style="padding:15px;background: white;margin-top: 10px;">
		<h6 style="font-weight: 500;margin-top: 5px;">Customer Option</h6>
		<!-- column section -->
		<div class="row" style="margin-top: 15px;">
			<div class="col l4 m4 s4" style="padding: 10px 2px;">
				<a href="<?= base_url('index.php/Home/udhar_entry/'.$profile->customer_id); ?>" style="color: black;"><h6 class="center-align"><span class="fas fa-file" style="font-size: 20px;color: grey;"></span></h6>
				<h6 class="center-align" style="color: grey;font-size: 14px;">Udhar Entry</h6>
			</a>
			</div>

			<div class="col l4 m4 s4" style="padding: 10px 2px;">
				<a href="<?= base_url('index.php/Home/payment_entry/'.$profile->customer_id); ?>" style="color: black;"><h6 class="center-align"><span class="fas fa-rupee-sign" style="font-size: 20px;color: grey;"></span></h6>
				<h6 class="center-align" style="color: grey;font-size: 14px;">Payment Entry</h6>
			</a>
			</div>

			<div class="col l4 m4 s4" style="padding: 10px 2px;">
				<a href="<?= base_url('index.php/Home/view_profile/'.$profile->customer_id); ?>" style="color: black;"><h6 class="center-align"><span class="fas fa-user" style="font-size: 20px;color: grey;"></span></h6>
				<h6 class="center-align" style="color: grey;font-size: 14px;">View Profile</h6>
			</a>
			</div>

			<div class="col l4 m4 s4" style="padding: 10px 2px;">
				<a href="<?= base_url('index.php/Home/udhar_history/'.$profile->customer_id); ?>" style="color: black;"><h6 class="center-align"><span class="fas fa-book" style="font-size: 20px;color: grey;"></span></h6>
				<h6 class="center-align" style="color: grey;font-size: 14px;">Udhar History</h6>
			</a>
			</div>

			<div class="col l4 m4 s4" style="padding: 10px 2px;">
				<a href="<?= base_url('index.php/Home/pay_history/'.$profile->customer_id); ?>" style="color: black;"><h6 class="center-align"><span class="fas fa-book" style="font-size: 20px;color: grey;"></span></h6>
				<h6 class="center-align" style="color: grey;font-size: 14px;">Pay History</h6>
			</a>
			</div>
		</div>
		<!-- colmun section -->
		<a href="<?= base_url('index.php/Home/dashboard'); ?>" class="btn waves-effect waves-light" style="background: #9c24b0;width: 100%;height: 45px;line-height: 45px;border-top-left-radius: 50px;border-top-right-radius: 50px;border-bottom-left-radius: 50px;border-bottom-right-radius: 50px;font-weight: 500;">Back to Dashboard</a>
		<br/><br/>
	</div>
	<!-- customer option section -->
	<!-- body section -->
<?php $this->load->view('Home/js-file'); ?>
</body>
</html>