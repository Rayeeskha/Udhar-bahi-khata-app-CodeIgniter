<script type="text/javascript" src="<?= base_url('assets/materialize/js/jquery.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/materialize/js/materialize.js'); ?>"></script>
<!-- custom js file include -->
<script type="text/javascript">
	$(document).ready(function(){
		// sidenav script
		$('.sidenav').sidenav();
		// sidenav script

		// tab script
		$('.tabs').tabs();
		// tab script
	});
</script>