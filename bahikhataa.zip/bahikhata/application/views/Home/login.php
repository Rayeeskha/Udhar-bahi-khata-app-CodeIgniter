<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<html>
<head>
	<title>Udhar Bahikhata - login</title>
	<?php $this->load->view('Home/css-file'); ?>
	<style type="text/css">
		body{background: white;}
		.container{width: 100%;padding: 25px;}
		#mobile_no,#password{background: white;border-radius: 3px;box-shadow: none;font-size: 18px;font-weight: 500;width: 100%;height: 45px;color: black;border:2px solid silver;text-align: center;}
	</style>
</head>
<body>
	<!-- login from section -->
	<div class="container">
		<h5 style="color: black;font-weight: 500;margin-bottom: 15px;margin-top: 5%;">नमस्कार दोस्तों !</h5>
		<h5 style="margin-top: 20px;font-weight: 400;">Welcome</h5>
		<h6 style="color: grey;margin-top: 0px;margin-bottom: 25px;">Signin with Your Mobile No. & Password</h6>
		<?= form_open('Home/login_vendor'); ?>
		<h6 style="font-weight: 500;">Mobile No.</h6>
		<input type="text" name="mobile_no" id="mobile_no" placeholder="+91 - 1234567890" autofocus autocomplete="off" required>
		<h6 style="font-weight: 500;">Password</h6>
		<input type="password" name="password" id="password" placeholder="XXXXXXXXXX" autofocus autocomplete="off" required>
		<button type="submit" class="btn waves-effect waves-light" style="width: 100%;height: 48px;font-size: 18px;line-height: 48px;font-weight: 400;background-image: linear-gradient(to left, #9c27b0, #ce93d8);margin-top: 25px;">Sign in</button>
		<?= form_close(); ?>
	</div>
	<!-- login form section -->
<?php $this->load->view('Home/js-file'); ?>
</body>
</html>