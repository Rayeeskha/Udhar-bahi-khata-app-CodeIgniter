<?php

/*
	@Website : http://code.deesoftservice.co.in/
	@Developer : Deepak Tailor
	@Mail      : deesoftservice@gmail.com
	@Created   : 23th Feb, 2020
	@Developed : Deesoft Service
*/

function indian_time()
{
	date_default_timezone_set('Asia/Kolkata');
}

?>