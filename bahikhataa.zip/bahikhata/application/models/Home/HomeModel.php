<?php

/*
	@Website : http://code.deesoftservice.co.in/
	@Developer : Deepak Tailor
	@Mail      : deesoftservice@gmail.com
	@Created   : 23th Feb, 2020
	@Developed : Deesoft Service
*/

class HomeModel extends CI_Model
{
	public function login_vendor($username,$password)
	{
		$check_login = $this->db->get_where('vendors',['vendor_username'=>$username,'vendor_password'=>$password]);
		if($check_login->num_rows() > 0){
			return true;
		}
		else{
			return false;
		}
	}

	public function submit_customer($name,$mobile,$address)
	{
		$insert_customer = $this->db->insert('customers',['name'=>$name,'mobile'=>$mobile,'address'=>$address,'month'=>date('m'),'date'=>date('Y-m-d')]);
		if($insert_customer){
			return true;
		}
		else{
			return false;
		}
	}

	public function update_customer($customer_name,$mobile_no,$address,$customer_id)
	{
		$update_customer = $this->db->where('customer_id',$customer_id)
				 ->update('customers',['name'=>$customer_name,'mobile'=>$mobile_no,'address'=>$address]);
		if($update_customer){
			return true;
		}
		else{
			return false;
		}
	}

	public function all_customer()
	{
		$get_customer = $this->db->select()
				 ->from('customers')
				 ->order_by('customer_id','desc')
				 ->get();
		if($get_customer->num_rows() > 0){
			return $get_customer->result();
		}
		else{
			return $get_customer->result();
		}
	}

	public function get_customer_profile($customer_id)
	{
		$get_profile = $this->db->get_where('customers',['customer_id'=>$customer_id]);
		if($get_profile->num_rows() > 0){
			return $get_profile->row();
		}
		else{
			return redirect('Home/not_found');
		}
	}

	public function submit_udhar_entry($cname,$amount,$udhar_desc,$cid,$time)
	{
		$submit_entry = $this->db->insert('udhar_entries',['customer_name'=>$cname,'amount'=>$amount,'udhar_desc'=>$udhar_desc,'customer_id'=>$cid,'udhar_date'=>date('Y-m-d'),'time'=>$time,'status'=>'Unpaid']);
		if($submit_entry){
			/* return insert id */
			$insert_id = $this->db->insert_id();
			/* return insert id */

			/* get customer all udhar amount */
			$customer_udhar = $this->db->get_where('udhar_entries',['customer_id'=>$cid,'status'=>'Unpaid']);
			if($customer_udhar->num_rows() > 0){
				$cus_data = $customer_udhar->result();
			}
			else{
				$cus_data = $customer_udhar->result();
			}
			$count_amount = 0; 
			if(count($cus_data)){
				foreach($cus_data as $c_data){
					$count_amount += $c_data->amount;
				}
			}
			else{
				$count_amount = 0;
			}
			/* get customer all udhar amount */

			/* get advance payment customer */
			$get_customer_adv = $this->db->get_where('customers',['customer_id'=>$cid]);
			if($get_customer_adv->num_rows() > 0){
				$cus_adv = $get_customer_adv->row();
			}
			else{
				return redirect('Home/not_found');
			}
			/* get advance payment customer */

			$advnace_pay = $cus_adv->pay_amount;

			$due_pay = $count_amount - $advnace_pay;

			/* update customer amount */ 
			if($advnace_pay > $due_pay){
				/* update last udhar status */
				$update_amount = $this->db->where('udhar_id',$insert_id)
						 ->update('udhar_entries',['status'=>'Paid']);
				/* update last udhar status */

				$update_amount = $this->db->where('customer_id',$cid)
					 ->update('customers',['pay_amount'=>str_replace("-","",$due_pay)]);
			}
			else{
				$update_amount = $this->db->where('customer_id',$cid)
					 ->update('customers',['udhar_amount'=>$due_pay]);
			}
			if($update_amount){
				return true;
			}
			else{
				return false;
			}
			/* update customer amount */ 
		}
		else{
			return false;
		}
	}

	public function all_udhar()
	{
		$get_udhar = $this->db->select()
				 ->from('udhar_entries')
				 ->order_by('udhar_id','desc')
				 ->get();
		if($get_udhar->num_rows() > 0){
			return $get_udhar->result();
		}
		else{
			return $get_udhar->result();
		}
	}

	public function udhar_amount()
	{
		$get_udahr_entry = $this->db->select()
				->from('udhar_entries')
				->where('status','Unpaid')
				->get();
		if($get_udahr_entry->num_rows() > 0){
			return $get_udahr_entry->result();
		}
		else{
			return $get_udahr_entry->result();
		}
	}

	public function submit_payment_entry($cname,$udhar_amount,$pay_amount,$time,$cid)
	{
		$insert_payment = $this->db->insert('payment_entries',['customer_name'=>$cname,'udhar_amount'=>$udhar_amount,'payment_amount'=>$pay_amount,'customer_id'=>$cid,'date'=>date('Y-m-d'),'time'=>$time]);
		if($insert_payment){
			//return true;

			/* calculate amount */
			$total_udhar =  $udhar_amount - $pay_amount;
			if($total_udhar > 0){
				$update_udhar = $this->db->where('customer_id',$cid)
					 ->update('customers',['udhar_amount'=>$total_udhar]);
			}
			else{
				$update_udhar = $this->db->where('customer_id',$cid)
					 ->update('customers',['pay_amount'=>str_replace("-", "", $total_udhar),'udhar_amount'=>'0']);

					 /* update customer udhar entry */ 
				$update_udhar = $this->db->where('customer_id',$cid)
					 		  ->update('udhar_entries',['status'=>'Paid']);
					 /* update customer udhar entry */
			}
			
			if($update_udhar){
				return true;
			}
			else{
				return false;
			}
			/* calculate amount */
		}
		else{
			return false;
		}
	}

	public function single_payment($udhar_id)
	{
		$check_udhar = $this->db->get_where('udhar_entries',['udhar_id'=>$udhar_id]);
		if($check_udhar->num_rows() > 0){
			$update_udhar = $this->db->where('udhar_id',$udhar_id)
				 ->update('udhar_entries',['status'=>'Paid']);
			if($update_udhar){
				//return true;
				$udhar_data = $check_udhar->row();
				$customer_id = $udhar_data->customer_id;
				$amount = $udhar_data->amount;

				$get_c_data = $this->db->get_where('customers',['customer_id'=>$customer_id]);
				if($get_c_data->num_rows() > 0){
					$cus_data = $get_c_data->row();
					$old_udhar_amount = $cus_data->udhar_amount;

					$total_udhar_amount = $old_udhar_amount - $amount;

					$update_udhar_amount = $this->db->where('customer_id',$customer_id)
							 ->update('customers',['udhar_amount'=>$total_udhar_amount]);
					if($update_udhar_amount){
						return true;
					}
					else{
						return false;
					}
				}
				else{
					return false;
				}
			}
			else{
				return redirect('Home/not_found');
			}
		}
		else{
			return redirect('Home/not_found');
		}
	}

	public function all_payments()
	{
		$get_payment = $this->db->select()
				 ->from('payment_entries')
				 ->order_by('payment_id','desc')
				 ->get();
		if($get_payment->num_rows() > 0){
			return $get_payment->result();
		}
		else{
			return $get_payment->result();
		}
	}

	public function pay_amounts()
	{
		$get_payment = $this->db->select()
				 ->from('payment_entries')
				 ->get();
		if($get_payment->num_rows() > 0){
			return $get_payment->result();
		}
		else{
			return $get_payment->result();
		}
	}

	public function my_udhar_history($customer_id)
	{
		$get_udhar = $this->db->get_where('udhar_entries',['customer_id'=>$customer_id,'status'=>'Unpaid']);
		if($get_udhar->num_rows() > 0){
			return $get_udhar->result();
		}
		else{
			return $get_udhar->result();
		}
	}

	public function my_payment_history($customer_id)
	{
		$get_udhar = $this->db->get_where('payment_entries',['customer_id'=>$customer_id]);
		if($get_udhar->num_rows() > 0){
			return $get_udhar->result();
		}
		else{
			return $get_udhar->result();
		}
	}
}
?>