<?php
/*
	@Website : http://code.deesoftservice.co.in/
	@Developer : Deepak Tailor
	@Mail      : deesoftservice@gmail.com
	@Created   : 23th Feb, 2020
	@Developed : Deesoft Service
*/
class Home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Home/HomeModel','hm');
	}

	public function index()
	{
		$this->load->view('Home/login');
	}

	public function not_found()
	{
		echo "404 Data Not found.";
	}

	public function login_vendor()
	{
		$username = $this->input->post('mobile_no');
		$password = $this->input->post('password');
		if($username || $password){
			$result = $this->hm->login_vendor($username,$password);
			if($result){
				$save_vendor_session = [
					'vendor_username'	=>	$username,
					'vendor_password'	=>	$password
				];
				$this->session->set_userdata($save_vendor_session);
				return redirect('Home/dashboard');
			}
		}
		else{
			return redirect('Home/index');
		}
	}

	public function dashboard()
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$all_customer = $this->hm->all_customer();
			$all_udhar = $this->hm->udhar_amount();
			$all_pay = $this->hm->pay_amounts();
			$this->load->view('Home/dashboard',['all_customer'=>$all_customer,'udhar_amount'=>$all_udhar,'pay_amount'=>$all_pay]);
		}
	}

	public function logout()
	{
		$this->session->unset_userdata('vendor_username');
		$this->session->unset_userdata('vendor_password');
		return redirect('Home/index');
	}

	public function payment_entry($customer_id)
	{
		$customer_profile = $this->hm->get_customer_profile($customer_id);
		$this->load->view('Home/payment_entry',['profile'=>$customer_profile]);
	}

	public function new_customer()
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$this->load->view('Home/new_customer');
		}
	}

	public function submit_customer()
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$customer_name = $this->input->post('customer_name');
			$mobile_no = $this->input->post('mobile_no');
			$address = $this->input->post('address');

			if($customer_name || $mobile_no){
				$result = $this->hm->submit_customer($customer_name,$mobile_no,$address);
				if($result){
					$this->session->set_flashdata('msg','Customer Register Successfully.');
					return redirect('Home/new_customer');
				}
				else{
					$this->session->set_flashdata('msg','Customer Register Fail.');
					return redirect('Home/new_customer');
				}
			}
			else{
				return redirect('Home/new_customer');
			}
		}
	}

	public function update_customer($customer_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$customer_name = $this->input->post('customer_name');
			$mobile_no = $this->input->post('mobile_no');
			$address = $this->input->post('address');

			if($customer_name || $mobile_no){
				$result = $this->hm->update_customer($customer_name,$mobile_no,$address,$customer_id);
				if($result){
					$this->session->set_flashdata('msg','Customer Update Successfully.');
					return redirect('Home/view_profile/'.$customer_id);
				}
				else{
					$this->session->set_flashdata('msg','Customer Update Fail.');
					return redirect('Home/view_profile/'.$customer_id);
				}
			}
			else{
				return redirect('Home/view_profile/'.$customer_id);
			}
		}
	}

	public function all_data_manage($tab)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$all_customer = $this->hm->all_customer();
			$all_udhar = $this->hm->all_udhar();
			$payments = $this->hm->all_payments();
			$this->load->view('Home/main-page',['tab'=>$tab,'all_customer'=>$all_customer,'all_udhar'=>$all_udhar,'payments'=>$payments]);
		}
	}

	public function udhar_entry($customer_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$customer_profile = $this->hm->get_customer_profile($customer_id);
			$this->load->view('Home/new_udhar_entry',['profile'=>$customer_profile]);
		}
	}

	public function submit_udhar_entry($customer_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$cname = $this->input->post('customer_name');
			$amount = $this->input->post('amount');
			$udhar_desc = $this->input->post('udhar_desc');
			indian_time();
			$time = date('h.i A',time());
			if($cname || $amount){
				$result = $this->hm->submit_udhar_entry($cname,$amount,$udhar_desc,$customer_id,$time);
				if($result){
					$this->session->set_flashdata('msg','Customer Udhar Entry Successfully.');
					return redirect('Home/udhar_entry/'.$customer_id);
				}
				else{
					$this->session->set_flashdata('msg','Customer Udhar Entry Fail.');
					return redirect('Home/udhar_entry/'.$customer_id);
				}
			}
			else{
				return redirect('Home/udhar_entry/'.$customer_id);
			}
		}
	}

	public function submit_payment_entry($customer_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$cname = $this->input->post('customer_name');
			$udhar_amount = $this->input->post('udhar_amount');
			$pay_amount = $this->input->post('pay_amount');
			indian_time();
			$time = date('h.i A',time());
			if($cname || $udhar_amount || $pay_amount){
				if($pay_amount == $udhar_amount){
					$result = $this->hm->submit_payment_entry($cname,$udhar_amount,$pay_amount,$time,$customer_id);
					if($result){
						$this->session->set_flashdata('msg','Customer Payment Entry Successfully.');
						return redirect('Home/payment_entry/'.$customer_id);
					}
					else{
						$this->session->set_flashdata('msg','Customer Payment Entry Fail.');
						return redirect('Home/payment_entry/'.$customer_id);
					}
				}
				else{
					$this->session->set_flashdata('msg','Please Enter Currect Amount.');
					return redirect('Home/payment_entry/'.$customer_id);	
				}
			}
			else{
				return redirect('Home/payment_entry/'.$customer_id);
			}
		}
	}

	public function customer_option($customer_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$customer_profile = $this->hm->get_customer_profile($customer_id);
			$this->load->view('Home/customer_option',['profile'=>$customer_profile]);
		}
	}

	public function single_payment($udhar_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$result = $this->hm->single_payment($udhar_id);
			if($result){
				$this->session->set_flashdata('msg','Congtratulation ! Payment Successfully.');
					return redirect('Home/all_data_manage/udhar');
			}
			else{
				$this->session->set_flashdata('msg','Error ! Payment Fail.');
					return redirect('Home/all_data_manage/udhar');
			}
		}
	}

	public function view_profile($customer_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$profile = $this->hm->get_customer_profile($customer_id);
			if($profile){
				$this->load->view('Home/view_profile',['profile'=>$profile]);
			}
			else{
				return redirect('Home/not_found');
			}
		}
	}

	public function udhar_history($customer_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$my_udhar = $this->hm->my_udhar_history($customer_id);
			$this->load->view('Home/udhar_history',['udhar_history'=>$my_udhar]);
		}
	}

	public function pay_history($customer_id)
	{
		if($this->session->userdata('vendor_username') == "" && $this->session->userdata('vendor_password') == ""){
			return redirect('Home/index');
		}
		else{
			$my_payment = $this->hm->my_payment_history($customer_id);
			$this->load->view('Home/payment_history',['payment_history'=>$my_payment]);
		}
	}
}
?>